package com.example.alex.player_demo_2.common;

public class Constants {
    public final static int SHOW_ALL_SERIALS = 100;
}
