package com.example.alex.player_demo_2;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.example.alex.player_demo_2.common.Constants;
import com.example.alex.player_demo_2.models.Rate;
import com.example.alex.player_demo_2.models.SerialInfo;
import com.example.alex.player_demo_2.models.SerialInfoShort;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ParseAllSerials {

    private Document document;

    public ParseAllSerials(Document document) {
        this.document = document;
    }

    public Document getDocument() {
        return document;
    }

    public void setDocument(Document document) {
        this.document = document;
    }


    public ArrayList<SerialInfoShort> getSerialsBlock(String dataId) {
        ArrayList<SerialInfoShort> serials = new ArrayList<>();
        Elements alphaList = document.select("#short > div");
        String baseUrl = document.baseUri();
        for (Element block : alphaList) {
            String titleRus = block.selectFirst("div.sh-desc > a > div").text();
            String titleEng = block.selectFirst("div.sh-desc > div:nth-child(2)").text();
            String title = String.format("%s%n%s", titleRus, titleEng);
            String link = block.selectFirst("div.sh-desc > a").attr("href");
            String descrip = block.selectFirst("div.sh-desc > div:nth-child(3)").text();
            String imgAnime = Utils.BASE_URL + block.selectFirst("a > img").attr("src");
            String status = block.selectFirst("a > div.short-meta.short-label.sl-y").text();
            SerialInfoShort serialInfo = new SerialInfoShort(link, titleRus, descrip, imgAnime, status);
            serials.add(serialInfo);
        }
        return serials;
    }



    /*private class DownloadPoster extends AsyncTask<String, Void, Document> {

        private String siteUrl;
        private SerialInfoShort serialInfoShort;

        public DownloadPoster(String siteUrl, SerialInfoShort serialInfoShort) {
            this.siteUrl = siteUrl;
            this.serialInfoShort = serialInfoShort;
        }

        public SerialInfoShort getSerialInfoShort() {
            return serialInfoShort;
        }

        public void setSerialInfoShort(SerialInfoShort serialInfoShort) {
            this.serialInfoShort = serialInfoShort;
        }

        public String getSiteUrl() {
            return siteUrl;
        }

        public void setSiteUrl(String siteUrl) {
            this.siteUrl = siteUrl;
        }


        @Override
        protected Document doInBackground(String... strings) {
            Document doc = null;
            try {
                doc = Jsoup.connect(siteUrl).get();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return doc;
        }

        @Override
        protected void onPostExecute(Document document) {
            ParseSerialDetail parseSerialDetail = new ParseSerialDetail(document);

            String genre = parseSerialDetail.getGenre();
            String poster = parseSerialDetail.getPosterUrl();

            Log.i("GENREEEEEEEEEEE", genre);
            Log.i("POSTEEEER", poster);

            serialInfoShort.setGenre(genre);
            serialInfoShort.setPosterUrl(poster);
        }
    }*/

}
